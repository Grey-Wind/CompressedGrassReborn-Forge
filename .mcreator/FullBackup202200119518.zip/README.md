# CompressedGrass:Reborn
 releases：https://github.com/Adenx0/Compressed_Grass_Reborn/releases 
 
 mcbbs：https://www.mcbbs.net/thread-1332428-1-1.html
 


The remade Compressed Grass made by Adenx updates the original 1.7.10 version of the module to 1.16.5. I will gradually improve and add the content that the original author did not add before.
