# About

[View Chinese readme](https://github.com/Adenx0/Compressed_Grass_Reborn/blob/main/README_CN.md)

[Download releases](https://github.com/Adenx0/Compressed_Grass_Reborn/releases)

[mcbbs](https://www.mcbbs.net/thread-1332428-1-1.html)

[Fabric version(unfinished)](https://github.com/Adenx0/CompressedGrassReborn-Fabric)

The remade Compressed Grass made by Adenx updates the original 1.7.10 version of the module to 1.16.5. I will gradually improve and add the content that the original author did not add before.

# Cooperation

I have sent a request to NeversXD(author of 1.7.10) on CurseForge to co-produce version 1.16.5. I found the user with the same name on Github, but I couldn't check the warehouse, so I didn't send a message to him on Github.

If you would like to work with me on this project (or any other project). Please call :15221369620(China) or email to 1953438158@qq.com

# Sponsor

I don't have the Paypal, so please use Alipay or Wechat.

First Qr code is Alipay,the second is Wechat.

![1658632943015](image/README/1658632943015.png "Alipay")![1658632951516](image/README/1658632951516.png "Wechat")
