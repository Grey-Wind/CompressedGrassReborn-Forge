# 关于

下载[正式版](https://github.com/Adenx0/Compressed_Grass_Reborn/releases)

访问[mcbbs](https://www.mcbbs.net/thread-1332428-1-1.html)

[Fabric版本](https://github.com/Adenx0/CompressedGrassReborn-Fabric)(未完成)

由AT Studio制作的压缩草重制版将原模组的1.7.10版本更新为1.16.5。我会逐步完善并添加原作者之前没有添加的内容。

# 合作

我已经向CurseForge上的NeversXD(1.7.10版本的作者)发送了一个请求，希望共同开发1.16.5版本。虽然我在Github上找到了同名的用户，但由于我查不到仓库，所以我没有在Github上给他发消息。

如果你愿意和我一起做这个项目(或任何其他项目)。请致电:15221369620(中国)或发邮件至1953438158@qq.com

# 赞助

我没有Paypal，所以请用支付宝或微信支付。

第一张是支付宝，第二张是微信。

![1658632943015](image/README/1658632943015.png "支付宝")![1658632951516](image/README/1658632951516.png "微信")
