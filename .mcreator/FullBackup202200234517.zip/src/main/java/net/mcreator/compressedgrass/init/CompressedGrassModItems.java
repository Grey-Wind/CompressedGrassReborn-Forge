
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.compressedgrass.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.compressedgrass.item.WindingGrassSticksItem;
import net.mcreator.compressedgrass.item.Upgrade1Item;
import net.mcreator.compressedgrass.item.TripleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassItem;
import net.mcreator.compressedgrass.item.TripleCompressedGrassArmorArmorItem;
import net.mcreator.compressedgrass.item.TechnobladeNeverDiesItem;
import net.mcreator.compressedgrass.item.TechnobladeItem;
import net.mcreator.compressedgrass.item.SpawnAuthorItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.SextupleCompressedGrassArmorArmorItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.SeptupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.SeptupleArmorItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.QuintupleCompressedGrassArmorArmorItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.QuadrupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.QuadrupleArmorItem;
import net.mcreator.compressedgrass.item.PotatoKingItem;
import net.mcreator.compressedgrass.item.OctupleGrassSwordItem;
import net.mcreator.compressedgrass.item.OctupleGrassShovelItem;
import net.mcreator.compressedgrass.item.OctupleGrassPickaxeItem;
import net.mcreator.compressedgrass.item.OctupleGrassHoeItem;
import net.mcreator.compressedgrass.item.OctupleGrassAxeItem;
import net.mcreator.compressedgrass.item.OctupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.OctupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.OctupleArmorItem;
import net.mcreator.compressedgrass.item.NonupleGrassSwordItem;
import net.mcreator.compressedgrass.item.NonupleGrassShovelItem;
import net.mcreator.compressedgrass.item.NonupleGrassPickaxeItem;
import net.mcreator.compressedgrass.item.NonupleGrassHoeItem;
import net.mcreator.compressedgrass.item.NonupleGrassAxeItem;
import net.mcreator.compressedgrass.item.NonupleGrassArmorItem;
import net.mcreator.compressedgrass.item.NonupleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.NonupleCompressedGrassItem;
import net.mcreator.compressedgrass.item.LimitSwordItem;
import net.mcreator.compressedgrass.item.LimitShovelItem;
import net.mcreator.compressedgrass.item.LimitPickaxeItem;
import net.mcreator.compressedgrass.item.LimitHoeItem;
import net.mcreator.compressedgrass.item.LimitCompressedGrassItem;
import net.mcreator.compressedgrass.item.LimitAxeItem;
import net.mcreator.compressedgrass.item.LimitArmorItem;
import net.mcreator.compressedgrass.item.IncreaseCapacityPlusItem;
import net.mcreator.compressedgrass.item.IncreaseCapacityItem;
import net.mcreator.compressedgrass.item.GrassStringItem;
import net.mcreator.compressedgrass.item.GrassStarItem;
import net.mcreator.compressedgrass.item.GrassNuggetItem;
import net.mcreator.compressedgrass.item.GrassIngotItem;
import net.mcreator.compressedgrass.item.GrassDimensionItem;
import net.mcreator.compressedgrass.item.GrassBagItem;
import net.mcreator.compressedgrass.item.EnchantedSwordItem;
import net.mcreator.compressedgrass.item.EnchantedShovelItem;
import net.mcreator.compressedgrass.item.EnchantedPickaxeItem;
import net.mcreator.compressedgrass.item.EnchantedHoeItem;
import net.mcreator.compressedgrass.item.EnchantedGrassItem;
import net.mcreator.compressedgrass.item.EnchantedAxeItem;
import net.mcreator.compressedgrass.item.EnchantedArmorItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassToolsSwordItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassToolsShovelItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassToolsPickaxeItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassToolsHoeItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassToolsAxeItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassStringItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassItem;
import net.mcreator.compressedgrass.item.DoubleCompressedGrassArmorArmorItem;
import net.mcreator.compressedgrass.item.CompressedSwordItem;
import net.mcreator.compressedgrass.item.CompressedShovelItem;
import net.mcreator.compressedgrass.item.CompressedPickaxeItem;
import net.mcreator.compressedgrass.item.CompressedHoeItem;
import net.mcreator.compressedgrass.item.CompressedGrassStringItem;
import net.mcreator.compressedgrass.item.CompressedGrassItem;
import net.mcreator.compressedgrass.item.CompressedGrassArmorArmorItem;
import net.mcreator.compressedgrass.item.CompressedAxeItem;
import net.mcreator.compressedgrass.item.BrokenGrassNuggetItem;
import net.mcreator.compressedgrass.item.BigGrassBagPlusItem;
import net.mcreator.compressedgrass.item.BigGrassBagItem;
import net.mcreator.compressedgrass.CompressedGrassMod;

public class CompressedGrassModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CompressedGrassMod.MODID);
	public static final RegistryObject<Item> COMPRESSED_GRASS = REGISTRY.register("compressed_grass", () -> new CompressedGrassItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS = REGISTRY.register("double_compressed_grass",
			() -> new DoubleCompressedGrassItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS = REGISTRY.register("triple_compressed_grass",
			() -> new TripleCompressedGrassItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS = REGISTRY.register("quadruple_compressed_grass",
			() -> new QuadrupleCompressedGrassItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS = REGISTRY.register("quintuple_compressed_grass",
			() -> new QuintupleCompressedGrassItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS = REGISTRY.register("sextuple_compressed_grass",
			() -> new SextupleCompressedGrassItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS = REGISTRY.register("septuple_compressed_grass",
			() -> new SeptupleCompressedGrassItem());
	public static final RegistryObject<Item> OCTUPLE_COMPRESSED_GRASS = REGISTRY.register("octuple_compressed_grass",
			() -> new OctupleCompressedGrassItem());
	public static final RegistryObject<Item> NONUPLE_COMPRESSED_GRASS = REGISTRY.register("nonuple_compressed_grass",
			() -> new NonupleCompressedGrassItem());
	public static final RegistryObject<Item> GRASS_STRING = REGISTRY.register("grass_string", () -> new GrassStringItem());
	public static final RegistryObject<Item> COMPRESSED_GRASS_STRING = REGISTRY.register("compressed_grass_string",
			() -> new CompressedGrassStringItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_STRING = REGISTRY.register("double_compressed_grass_string",
			() -> new DoubleCompressedGrassStringItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("triple_compressed_grass_string",
			() -> new TripleCompressedGrassStringItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("quintuple_compressed_grass_string",
			() -> new QuintupleCompressedGrassStringItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("quadruple_compressed_grass_string",
			() -> new QuadrupleCompressedGrassStringItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("sextuple_compressed_grass_string",
			() -> new SextupleCompressedGrassStringItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("septuple_compressed_grass_string",
			() -> new SeptupleCompressedGrassStringItem());
	public static final RegistryObject<Item> OCTUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("octuple_compressed_grass_string",
			() -> new OctupleCompressedGrassStringItem());
	public static final RegistryObject<Item> NONUPLE_COMPRESSED_GRASS_STRING = REGISTRY.register("nonuple_compressed_grass_string",
			() -> new NonupleCompressedGrassStringItem());
	public static final RegistryObject<Item> WINDING_GRASS_STICKS = REGISTRY.register("winding_grass_sticks", () -> new WindingGrassSticksItem());
	public static final RegistryObject<Item> COMPRESSED_GRASS_MACHINE = block(CompressedGrassModBlocks.COMPRESSED_GRASS_MACHINE,
			CompressedGrassModTabs.TAB_GRASS);
	public static final RegistryObject<Item> COMPRESSED_GRASS_MACHINE_PLUS = block(CompressedGrassModBlocks.COMPRESSED_GRASS_MACHINE_PLUS,
			CompressedGrassModTabs.TAB_GRASS);
	public static final RegistryObject<Item> SPAWN_AUTHOR = REGISTRY.register("spawn_author", () -> new SpawnAuthorItem());
	public static final RegistryObject<Item> GRASS_CHEST = block(CompressedGrassModBlocks.GRASS_CHEST, CompressedGrassModTabs.TAB_STORAGE);
	public static final RegistryObject<Item> BIG_GRASS_CHEST = block(CompressedGrassModBlocks.BIG_GRASS_CHEST, CompressedGrassModTabs.TAB_STORAGE);
	public static final RegistryObject<Item> BIG_GRASS_CHEST_PLUS = block(CompressedGrassModBlocks.BIG_GRASS_CHEST_PLUS,
			CompressedGrassModTabs.TAB_STORAGE);
	public static final RegistryObject<Item> GRASS_BAG = REGISTRY.register("grass_bag", () -> new GrassBagItem());
	public static final RegistryObject<Item> BIG_GRASS_BAG = REGISTRY.register("big_grass_bag", () -> new BigGrassBagItem());
	public static final RegistryObject<Item> BIG_GRASS_BAG_PLUS = REGISTRY.register("big_grass_bag_plus", () -> new BigGrassBagPlusItem());
	public static final RegistryObject<Item> GRASS_WOOD_WOOD = block(CompressedGrassModBlocks.GRASS_WOOD_WOOD, CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_LOG = block(CompressedGrassModBlocks.GRASS_WOOD_LOG, CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_PLANKS = block(CompressedGrassModBlocks.GRASS_WOOD_PLANKS,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_STAIRS = block(CompressedGrassModBlocks.GRASS_WOOD_STAIRS,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_SLAB = block(CompressedGrassModBlocks.GRASS_WOOD_SLAB, CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_BUTTON = block(CompressedGrassModBlocks.GRASS_WOOD_BUTTON,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_LEAVES = block(CompressedGrassModBlocks.GRASS_WOOD_LEAVES,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_FENCE = block(CompressedGrassModBlocks.GRASS_WOOD_FENCE,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_FENCE_GATE = block(CompressedGrassModBlocks.GRASS_WOOD_FENCE_GATE,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> GRASS_WOOD_PRESSURE_PLATE = block(CompressedGrassModBlocks.GRASS_WOOD_PRESSURE_PLATE,
			CompressedGrassModTabs.TAB_GRASS_WOOD);
	public static final RegistryObject<Item> COMPRESSED_GRASS_ARMOR_ARMOR_HELMET = REGISTRY.register("compressed_grass_armor_armor_helmet",
			() -> new CompressedGrassArmorArmorItem.Helmet());
	public static final RegistryObject<Item> COMPRESSED_GRASS_ARMOR_ARMOR_CHESTPLATE = REGISTRY.register("compressed_grass_armor_armor_chestplate",
			() -> new CompressedGrassArmorArmorItem.Chestplate());
	public static final RegistryObject<Item> COMPRESSED_GRASS_ARMOR_ARMOR_LEGGINGS = REGISTRY.register("compressed_grass_armor_armor_leggings",
			() -> new CompressedGrassArmorArmorItem.Leggings());
	public static final RegistryObject<Item> COMPRESSED_GRASS_ARMOR_ARMOR_BOOTS = REGISTRY.register("compressed_grass_armor_armor_boots",
			() -> new CompressedGrassArmorArmorItem.Boots());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_ARMOR_ARMOR_HELMET = REGISTRY
			.register("double_compressed_grass_armor_armor_helmet", () -> new DoubleCompressedGrassArmorArmorItem.Helmet());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_ARMOR_ARMOR_CHESTPLATE = REGISTRY
			.register("double_compressed_grass_armor_armor_chestplate", () -> new DoubleCompressedGrassArmorArmorItem.Chestplate());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_ARMOR_ARMOR_LEGGINGS = REGISTRY
			.register("double_compressed_grass_armor_armor_leggings", () -> new DoubleCompressedGrassArmorArmorItem.Leggings());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_ARMOR_ARMOR_BOOTS = REGISTRY
			.register("double_compressed_grass_armor_armor_boots", () -> new DoubleCompressedGrassArmorArmorItem.Boots());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_ARMOR_ARMOR_HELMET = REGISTRY
			.register("triple_compressed_grass_armor_armor_helmet", () -> new TripleCompressedGrassArmorArmorItem.Helmet());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_ARMOR_ARMOR_CHESTPLATE = REGISTRY
			.register("triple_compressed_grass_armor_armor_chestplate", () -> new TripleCompressedGrassArmorArmorItem.Chestplate());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_ARMOR_ARMOR_LEGGINGS = REGISTRY
			.register("triple_compressed_grass_armor_armor_leggings", () -> new TripleCompressedGrassArmorArmorItem.Leggings());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_ARMOR_ARMOR_BOOTS = REGISTRY
			.register("triple_compressed_grass_armor_armor_boots", () -> new TripleCompressedGrassArmorArmorItem.Boots());
	public static final RegistryObject<Item> QUADRUPLE_ARMOR_HELMET = REGISTRY.register("quadruple_armor_helmet",
			() -> new QuadrupleArmorItem.Helmet());
	public static final RegistryObject<Item> QUADRUPLE_ARMOR_CHESTPLATE = REGISTRY.register("quadruple_armor_chestplate",
			() -> new QuadrupleArmorItem.Chestplate());
	public static final RegistryObject<Item> QUADRUPLE_ARMOR_LEGGINGS = REGISTRY.register("quadruple_armor_leggings",
			() -> new QuadrupleArmorItem.Leggings());
	public static final RegistryObject<Item> QUADRUPLE_ARMOR_BOOTS = REGISTRY.register("quadruple_armor_boots", () -> new QuadrupleArmorItem.Boots());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_HELMET = REGISTRY
			.register("quintuple_compressed_grass_armor_armor_helmet", () -> new QuintupleCompressedGrassArmorArmorItem.Helmet());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_CHESTPLATE = REGISTRY
			.register("quintuple_compressed_grass_armor_armor_chestplate", () -> new QuintupleCompressedGrassArmorArmorItem.Chestplate());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_LEGGINGS = REGISTRY
			.register("quintuple_compressed_grass_armor_armor_leggings", () -> new QuintupleCompressedGrassArmorArmorItem.Leggings());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_BOOTS = REGISTRY
			.register("quintuple_compressed_grass_armor_armor_boots", () -> new QuintupleCompressedGrassArmorArmorItem.Boots());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_HELMET = REGISTRY
			.register("sextuple_compressed_grass_armor_armor_helmet", () -> new SextupleCompressedGrassArmorArmorItem.Helmet());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_CHESTPLATE = REGISTRY
			.register("sextuple_compressed_grass_armor_armor_chestplate", () -> new SextupleCompressedGrassArmorArmorItem.Chestplate());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_LEGGINGS = REGISTRY
			.register("sextuple_compressed_grass_armor_armor_leggings", () -> new SextupleCompressedGrassArmorArmorItem.Leggings());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_ARMOR_ARMOR_BOOTS = REGISTRY
			.register("sextuple_compressed_grass_armor_armor_boots", () -> new SextupleCompressedGrassArmorArmorItem.Boots());
	public static final RegistryObject<Item> SEPTUPLE_ARMOR_HELMET = REGISTRY.register("septuple_armor_helmet", () -> new SeptupleArmorItem.Helmet());
	public static final RegistryObject<Item> SEPTUPLE_ARMOR_CHESTPLATE = REGISTRY.register("septuple_armor_chestplate",
			() -> new SeptupleArmorItem.Chestplate());
	public static final RegistryObject<Item> SEPTUPLE_ARMOR_LEGGINGS = REGISTRY.register("septuple_armor_leggings",
			() -> new SeptupleArmorItem.Leggings());
	public static final RegistryObject<Item> SEPTUPLE_ARMOR_BOOTS = REGISTRY.register("septuple_armor_boots", () -> new SeptupleArmorItem.Boots());
	public static final RegistryObject<Item> OCTUPLE_ARMOR_HELMET = REGISTRY.register("octuple_armor_helmet", () -> new OctupleArmorItem.Helmet());
	public static final RegistryObject<Item> OCTUPLE_ARMOR_CHESTPLATE = REGISTRY.register("octuple_armor_chestplate",
			() -> new OctupleArmorItem.Chestplate());
	public static final RegistryObject<Item> OCTUPLE_ARMOR_LEGGINGS = REGISTRY.register("octuple_armor_leggings",
			() -> new OctupleArmorItem.Leggings());
	public static final RegistryObject<Item> OCTUPLE_ARMOR_BOOTS = REGISTRY.register("octuple_armor_boots", () -> new OctupleArmorItem.Boots());
	public static final RegistryObject<Item> NONUPLE_GRASS_ARMOR_HELMET = REGISTRY.register("nonuple_grass_armor_helmet",
			() -> new NonupleGrassArmorItem.Helmet());
	public static final RegistryObject<Item> NONUPLE_GRASS_ARMOR_CHESTPLATE = REGISTRY.register("nonuple_grass_armor_chestplate",
			() -> new NonupleGrassArmorItem.Chestplate());
	public static final RegistryObject<Item> NONUPLE_GRASS_ARMOR_LEGGINGS = REGISTRY.register("nonuple_grass_armor_leggings",
			() -> new NonupleGrassArmorItem.Leggings());
	public static final RegistryObject<Item> NONUPLE_GRASS_ARMOR_BOOTS = REGISTRY.register("nonuple_grass_armor_boots",
			() -> new NonupleGrassArmorItem.Boots());
	public static final RegistryObject<Item> COMPRESSED_PICKAXE = REGISTRY.register("compressed_pickaxe", () -> new CompressedPickaxeItem());
	public static final RegistryObject<Item> COMPRESSED_AXE = REGISTRY.register("compressed_axe", () -> new CompressedAxeItem());
	public static final RegistryObject<Item> COMPRESSED_SWORD = REGISTRY.register("compressed_sword", () -> new CompressedSwordItem());
	public static final RegistryObject<Item> COMPRESSED_SHOVEL = REGISTRY.register("compressed_shovel", () -> new CompressedShovelItem());
	public static final RegistryObject<Item> COMPRESSED_HOE = REGISTRY.register("compressed_hoe", () -> new CompressedHoeItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("double_compressed_grass_tools_pickaxe",
			() -> new DoubleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("double_compressed_grass_tools_axe",
			() -> new DoubleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("double_compressed_grass_tools_shovel",
			() -> new DoubleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("double_compressed_grass_tools_hoe",
			() -> new DoubleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("triple_compressed_grass_tools_pickaxe",
			() -> new TripleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("triple_compressed_grass_tools_axe",
			() -> new TripleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("triple_compressed_grass_tools_shovel",
			() -> new TripleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("triple_compressed_grass_tools_hoe",
			() -> new TripleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("quadruple_compressed_grass_tools_pickaxe",
			() -> new QuadrupleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("quadruple_compressed_grass_tools_axe",
			() -> new QuadrupleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("quadruple_compressed_grass_tools_shovel",
			() -> new QuadrupleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("quadruple_compressed_grass_tools_hoe",
			() -> new QuadrupleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("quintuple_compressed_grass_tools_pickaxe",
			() -> new QuintupleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("quintuple_compressed_grass_tools_axe",
			() -> new QuintupleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("quintuple_compressed_grass_tools_shovel",
			() -> new QuintupleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("quintuple_compressed_grass_tools_hoe",
			() -> new QuintupleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("sextuple_compressed_grass_tools_pickaxe",
			() -> new SextupleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("sextuple_compressed_grass_tools_axe",
			() -> new SextupleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("sextuple_compressed_grass_tools_shovel",
			() -> new SextupleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("sextuple_compressed_grass_tools_hoe",
			() -> new SextupleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_TOOLS_PICKAXE = REGISTRY.register("septuple_compressed_grass_tools_pickaxe",
			() -> new SeptupleCompressedGrassToolsPickaxeItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_TOOLS_AXE = REGISTRY.register("septuple_compressed_grass_tools_axe",
			() -> new SeptupleCompressedGrassToolsAxeItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_TOOLS_SHOVEL = REGISTRY.register("septuple_compressed_grass_tools_shovel",
			() -> new SeptupleCompressedGrassToolsShovelItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_TOOLS_HOE = REGISTRY.register("septuple_compressed_grass_tools_hoe",
			() -> new SeptupleCompressedGrassToolsHoeItem());
	public static final RegistryObject<Item> GRASS_DIMENSION = REGISTRY.register("grass_dimension", () -> new GrassDimensionItem());
	public static final RegistryObject<Item> OCTUPLE_GRASS_PICKAXE = REGISTRY.register("octuple_grass_pickaxe", () -> new OctupleGrassPickaxeItem());
	public static final RegistryObject<Item> OCTUPLE_GRASS_AXE = REGISTRY.register("octuple_grass_axe", () -> new OctupleGrassAxeItem());
	public static final RegistryObject<Item> OCTUPLE_GRASS_SHOVEL = REGISTRY.register("octuple_grass_shovel", () -> new OctupleGrassShovelItem());
	public static final RegistryObject<Item> OCTUPLE_GRASS_HOE = REGISTRY.register("octuple_grass_hoe", () -> new OctupleGrassHoeItem());
	public static final RegistryObject<Item> NONUPLE_GRASS_PICKAXE = REGISTRY.register("nonuple_grass_pickaxe", () -> new NonupleGrassPickaxeItem());
	public static final RegistryObject<Item> NONUPLE_GRASS_AXE = REGISTRY.register("nonuple_grass_axe", () -> new NonupleGrassAxeItem());
	public static final RegistryObject<Item> NONUPLE_GRASS_SHOVEL = REGISTRY.register("nonuple_grass_shovel", () -> new NonupleGrassShovelItem());
	public static final RegistryObject<Item> NONUPLE_GRASS_HOE = REGISTRY.register("nonuple_grass_hoe", () -> new NonupleGrassHoeItem());
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("double_compressed_grass_tools_sword",
			() -> new DoubleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> TRIPLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("triple_compressed_grass_tools_sword",
			() -> new TripleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> QUADRUPLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("quadruple_compressed_grass_tools_sword",
			() -> new QuadrupleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> QUINTUPLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("quintuple_compressed_grass_tools_sword",
			() -> new QuintupleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> SEXTUPLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("sextuple_compressed_grass_tools_sword",
			() -> new SextupleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> SEPTUPLE_COMPRESSED_GRASS_TOOLS_SWORD = REGISTRY.register("septuple_compressed_grass_tools_sword",
			() -> new SeptupleCompressedGrassToolsSwordItem());
	public static final RegistryObject<Item> OCTUPLE_GRASS_SWORD = REGISTRY.register("octuple_grass_sword", () -> new OctupleGrassSwordItem());
	public static final RegistryObject<Item> NONUPLE_GRASS_SWORD = REGISTRY.register("nonuple_grass_sword", () -> new NonupleGrassSwordItem());
	public static final RegistryObject<Item> GRASS_ORE = block(CompressedGrassModBlocks.GRASS_ORE, CompressedGrassModTabs.TAB_GRASS_ORE_TAB);
	public static final RegistryObject<Item> BROKEN_GRASS_NUGGET = REGISTRY.register("broken_grass_nugget", () -> new BrokenGrassNuggetItem());
	public static final RegistryObject<Item> GRASS_NUGGET = REGISTRY.register("grass_nugget", () -> new GrassNuggetItem());
	public static final RegistryObject<Item> GRASS_INGOT = REGISTRY.register("grass_ingot", () -> new GrassIngotItem());
	public static final RegistryObject<Item> GRASS_BLOCK = block(CompressedGrassModBlocks.GRASS_BLOCK, CompressedGrassModTabs.TAB_GRASS_ORE_TAB);
	public static final RegistryObject<Item> GRASS_MONSTER = REGISTRY.register("grass_monster_spawn_egg",
			() -> new ForgeSpawnEggItem(CompressedGrassModEntities.GRASS_MONSTER, -1, -10066177,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> AUTHOR = REGISTRY.register("author_spawn_egg",
			() -> new ForgeSpawnEggItem(CompressedGrassModEntities.AUTHOR, -10029295, -16755968,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> TECHNOBLADE = REGISTRY.register("technoblade", () -> new TechnobladeItem());
	public static final RegistryObject<Item> POTATO_KING = REGISTRY.register("potato_king", () -> new PotatoKingItem());
	public static final RegistryObject<Item> TECHNOBLADE_NEVER_DIES = REGISTRY.register("technoblade_never_dies",
			() -> new TechnobladeNeverDiesItem());
	public static final RegistryObject<Item> GRASS_STAR = REGISTRY.register("grass_star", () -> new GrassStarItem());
	public static final RegistryObject<Item> INCREASE_CAPACITY = REGISTRY.register("increase_capacity", () -> new IncreaseCapacityItem());
	public static final RegistryObject<Item> INCREASE_CAPACITY_PLUS = REGISTRY.register("increase_capacity_plus",
			() -> new IncreaseCapacityPlusItem());
	public static final RegistryObject<Item> LIMIT_COMPRESSED_GRASS = REGISTRY.register("limit_compressed_grass",
			() -> new LimitCompressedGrassItem());
	public static final RegistryObject<Item> ENCHANTED_GRASS = REGISTRY.register("enchanted_grass", () -> new EnchantedGrassItem());
	public static final RegistryObject<Item> LIMIT_ARMOR_HELMET = REGISTRY.register("limit_armor_helmet", () -> new LimitArmorItem.Helmet());
	public static final RegistryObject<Item> LIMIT_ARMOR_CHESTPLATE = REGISTRY.register("limit_armor_chestplate",
			() -> new LimitArmorItem.Chestplate());
	public static final RegistryObject<Item> LIMIT_ARMOR_LEGGINGS = REGISTRY.register("limit_armor_leggings", () -> new LimitArmorItem.Leggings());
	public static final RegistryObject<Item> LIMIT_ARMOR_BOOTS = REGISTRY.register("limit_armor_boots", () -> new LimitArmorItem.Boots());
	public static final RegistryObject<Item> ENCHANTED_ARMOR_HELMET = REGISTRY.register("enchanted_armor_helmet",
			() -> new EnchantedArmorItem.Helmet());
	public static final RegistryObject<Item> ENCHANTED_ARMOR_CHESTPLATE = REGISTRY.register("enchanted_armor_chestplate",
			() -> new EnchantedArmorItem.Chestplate());
	public static final RegistryObject<Item> ENCHANTED_ARMOR_LEGGINGS = REGISTRY.register("enchanted_armor_leggings",
			() -> new EnchantedArmorItem.Leggings());
	public static final RegistryObject<Item> ENCHANTED_ARMOR_BOOTS = REGISTRY.register("enchanted_armor_boots", () -> new EnchantedArmorItem.Boots());
	public static final RegistryObject<Item> LIMIT_PICKAXE = REGISTRY.register("limit_pickaxe", () -> new LimitPickaxeItem());
	public static final RegistryObject<Item> LIMIT_AXE = REGISTRY.register("limit_axe", () -> new LimitAxeItem());
	public static final RegistryObject<Item> LIMIT_SWORD = REGISTRY.register("limit_sword", () -> new LimitSwordItem());
	public static final RegistryObject<Item> LIMIT_SHOVEL = REGISTRY.register("limit_shovel", () -> new LimitShovelItem());
	public static final RegistryObject<Item> LIMIT_HOE = REGISTRY.register("limit_hoe", () -> new LimitHoeItem());
	public static final RegistryObject<Item> ENCHANTED_PICKAXE = REGISTRY.register("enchanted_pickaxe", () -> new EnchantedPickaxeItem());
	public static final RegistryObject<Item> ENCHANTED_AXE = REGISTRY.register("enchanted_axe", () -> new EnchantedAxeItem());
	public static final RegistryObject<Item> ENCHANTED_SWORD = REGISTRY.register("enchanted_sword", () -> new EnchantedSwordItem());
	public static final RegistryObject<Item> ENCHANTED_SHOVEL = REGISTRY.register("enchanted_shovel", () -> new EnchantedShovelItem());
	public static final RegistryObject<Item> ENCHANTED_HOE = REGISTRY.register("enchanted_hoe", () -> new EnchantedHoeItem());
	public static final RegistryObject<Item> UPGRADE_1 = REGISTRY.register("upgrade_1", () -> new Upgrade1Item());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
