# 关于

[正式版](https://github.com/Adenx0/Compressed_Grass_Reborn/releases)

[Fabric版本(重启)](https://github.com/Adenx0/CompressedGrassReborn-Fabric)

[Gitee](https://gitee.com/adenx/compressed-grass-reborn)

由灰风制作的压缩草重制版将原模组的1.7.10版本更新为1.16.5。我会逐步完善并添加原作者之前没有添加的内容。

我由于某些原因将永久不会再mcbbs上发布任何内容，也不会再登录与使用mcbbs，如果需要发布相关内容可以联系我。

# 开发进度

打勾的为彻底完成

* [X] 迁移原作者内容
* [X] 盔甲
* [X] 工具
* [ ] 成就(需要改进和完善)
* [X] 矿物
* [X] 箱子与背包
* [X] 木头
* [ ] 维度(需要改进和完善)
* [X] boss-1
* [X] Technoblade物品
* [ ] 最终boss(未开始)

# 合作

我已经向CurseForge上的NeversXD(1.7.10版本的作者)发送了一个请求，希望共同开发1.16.5版本。虽然我在Github上找到了同名的用户，但由于我查不到仓库，所以我没有在Github上给他发消息。

如果你愿意和我一起做这个项目(或任何其他项目)。请致电:15221369620(中国)或发邮件至1953438158@qq.com

# 关于作者

本模组的作者是一名初中生，这也导致更新模组的时间较为缓慢。
而且现在已经初中三年级，临近中考，更新也会更为缓慢，主要会在假期更新。

# 赞助

我没有Paypal，所以请用支付宝或微信支付。

![1668321409087](image/README_CN/1668321409087.png)
